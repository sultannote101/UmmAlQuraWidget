package com.islamicwidget.ummalqura

import android.content.Context
import android.content.SharedPreferences

object WidgetPreferences {
    private const val PREFS_NAME = "UmmAlQuraWidgetPrefs"

    // Keys
    const val KEY_TEXT_SIZE = "text_size"
    const val KEY_BACKGROUND_COLOR = "bg_color"
    const val KEY_TEXT_COLOR = "text_color"
    const val KEY_SHOW_GREGORIAN = "show_gregorian"
    const val KEY_SHOW_DAY_NAME = "show_day_name"
    const val KEY_SHOW_OCCASION = "show_occasion"
    const val KEY_WIDGET_STYLE = "widget_style"
    const val KEY_SHOW_BORDER = "show_border"
    const val KEY_TRANSPARENCY = "transparency"
    const val KEY_FONT_TYPE = "font_type"
    const val KEY_WIDGET_SIZE = "widget_size"

    // Default values
    const val DEFAULT_TEXT_SIZE = 2 // Medium
    const val DEFAULT_BG_COLOR = "#CC1B5E3C" // Dark green with transparency
    const val DEFAULT_TEXT_COLOR = "#FFFFFFFF" // White
    const val DEFAULT_SHOW_GREGORIAN = true
    const val DEFAULT_SHOW_DAY_NAME = true
    const val DEFAULT_SHOW_OCCASION = true
    const val DEFAULT_WIDGET_STYLE = 0 // Classic
    const val DEFAULT_SHOW_BORDER = true
    const val DEFAULT_TRANSPARENCY = 80 // 80%
    const val DEFAULT_FONT_TYPE = 0 // Default Arabic
    const val DEFAULT_WIDGET_SIZE = 1 // Medium

    // Widget styles
    const val STYLE_CLASSIC = 0
    const val STYLE_MODERN = 1
    const val STYLE_MINIMAL = 2
    const val STYLE_GOLD = 3
    const val STYLE_DARK = 4
    const val STYLE_RAMADAN = 5

    // Text sizes
    const val SIZE_SMALL = 0
    const val SIZE_MEDIUM = 1
    const val SIZE_LARGE = 2
    const val SIZE_XLARGE = 3

    // Widget physical sizes
    const val WIDGET_SMALL = 0
    const val WIDGET_MEDIUM = 1
    const val WIDGET_LARGE = 2

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getInt(context: Context, key: String, default: Int): Int =
        prefs(context).getInt(key, default)

    fun getString(context: Context, key: String, default: String): String =
        prefs(context).getString(key, default) ?: default

    fun getBoolean(context: Context, key: String, default: Boolean): Boolean =
        prefs(context).getBoolean(key, default)

    fun setInt(context: Context, key: String, value: Int) =
        prefs(context).edit().putInt(key, value).apply()

    fun setString(context: Context, key: String, value: String) =
        prefs(context).edit().putString(key, value).apply()

    fun setBoolean(context: Context, key: String, value: Boolean) =
        prefs(context).edit().putBoolean(key, value).apply()

    // Style configurations
    data class StyleConfig(
        val backgroundColorHex: String,
        val textColorHex: String,
        val accentColorHex: String,
        val borderColorHex: String,
        val nameResId: Int
    )

    fun getStyleConfig(style: Int): StyleConfig {
        return when (style) {
            STYLE_CLASSIC -> StyleConfig("#CC1A6634", "#FFFFFFFF", "#FFD4AF37", "#FFD4AF37", R.string.style_classic)
            STYLE_MODERN -> StyleConfig("#EE2C3E50", "#FFFFFFFF", "#FF3498DB", "#FF3498DB", R.string.style_modern)
            STYLE_MINIMAL -> StyleConfig("#F5F5F5F5", "#FF1A1A2E", "#FF16213E", "#FF16213E", R.string.style_minimal)
            STYLE_GOLD -> StyleConfig("#EE8B6914", "#FFFFFFFF", "#FFFFD700", "#FFFFD700", R.string.style_gold)
            STYLE_DARK -> StyleConfig("#EE0D0D0D", "#FFFFFFFF", "#FF00BCD4", "#FF00BCD4", R.string.style_dark)
            STYLE_RAMADAN -> StyleConfig("#EE1A0533", "#FFFFFFFF", "#FFFF9800", "#FFFF9800", R.string.style_ramadan)
            else -> StyleConfig("#CC1A6634", "#FFFFFFFF", "#FFD4AF37", "#FFD4AF37", R.string.style_classic)
        }
    }
}
