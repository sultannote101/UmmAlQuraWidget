package com.islamicwidget.ummalqura

import android.app.Service
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.os.IBinder

class WidgetUpdateService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val mgr = AppWidgetManager.getInstance(this)
        val ids = mgr.getAppWidgetIds(ComponentName(this, UmmAlQuraWidget::class.java))
        for (id in ids) {
            UmmAlQuraWidget.updateWidget(this, mgr, id)
        }
        stopSelf()
        return START_NOT_STICKY
    }
}
