package com.islamicwidget.ummalqura

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    // Preview views
    private lateinit var previewContainer: LinearLayout
    private lateinit var tvPreviewDay: TextView
    private lateinit var tvPreviewDayName: TextView
    private lateinit var tvPreviewMonth: TextView
    private lateinit var tvPreviewYear: TextView
    private lateinit var tvPreviewGregorian: TextView
    private lateinit var tvPreviewOccasion: TextView

    // Control views
    private lateinit var spinnerStyle: Spinner
    private lateinit var spinnerTextSize: Spinner
    private lateinit var switchGregorian: Switch
    private lateinit var switchDayName: Switch
    private lateinit var switchOccasion: Switch
    private lateinit var switchBorder: Switch
    private lateinit var seekTransparency: SeekBar
    private lateinit var tvTransparencyValue: TextView
    private lateinit var btnApply: Button
    private lateinit var btnReset: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        supportActionBar?.title = getString(R.string.app_name)

        initViews()
        loadCurrentSettings()
        setupListeners()
        updatePreview()
    }

    private fun initViews() {
        previewContainer = findViewById(R.id.preview_container)
        tvPreviewDay = findViewById(R.id.tv_preview_day)
        tvPreviewDayName = findViewById(R.id.tv_preview_day_name)
        tvPreviewMonth = findViewById(R.id.tv_preview_month)
        tvPreviewYear = findViewById(R.id.tv_preview_year)
        tvPreviewGregorian = findViewById(R.id.tv_preview_gregorian)
        tvPreviewOccasion = findViewById(R.id.tv_preview_occasion)

        spinnerStyle = findViewById(R.id.spinner_style)
        spinnerTextSize = findViewById(R.id.spinner_text_size)
        switchGregorian = findViewById(R.id.switch_gregorian)
        switchDayName = findViewById(R.id.switch_day_name)
        switchOccasion = findViewById(R.id.switch_occasion)
        switchBorder = findViewById(R.id.switch_border)
        seekTransparency = findViewById(R.id.seek_transparency)
        tvTransparencyValue = findViewById(R.id.tv_transparency_value)
        btnApply = findViewById(R.id.btn_apply)
        btnReset = findViewById(R.id.btn_reset)

        // Setup spinners
        val styles = arrayOf(
            getString(R.string.style_classic),
            getString(R.string.style_modern),
            getString(R.string.style_minimal),
            getString(R.string.style_gold),
            getString(R.string.style_dark),
            getString(R.string.style_ramadan)
        )
        spinnerStyle.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, styles)

        val sizes = arrayOf(
            getString(R.string.size_small),
            getString(R.string.size_medium),
            getString(R.string.size_large),
            getString(R.string.size_xlarge)
        )
        spinnerTextSize.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, sizes)
    }

    private fun loadCurrentSettings() {
        val prefs = WidgetPreferences
        spinnerStyle.setSelection(prefs.getInt(this, WidgetPreferences.KEY_WIDGET_STYLE, WidgetPreferences.DEFAULT_WIDGET_STYLE))
        spinnerTextSize.setSelection(prefs.getInt(this, WidgetPreferences.KEY_TEXT_SIZE, WidgetPreferences.DEFAULT_TEXT_SIZE))
        switchGregorian.isChecked = prefs.getBoolean(this, WidgetPreferences.KEY_SHOW_GREGORIAN, WidgetPreferences.DEFAULT_SHOW_GREGORIAN)
        switchDayName.isChecked = prefs.getBoolean(this, WidgetPreferences.KEY_SHOW_DAY_NAME, WidgetPreferences.DEFAULT_SHOW_DAY_NAME)
        switchOccasion.isChecked = prefs.getBoolean(this, WidgetPreferences.KEY_SHOW_OCCASION, WidgetPreferences.DEFAULT_SHOW_OCCASION)
        switchBorder.isChecked = prefs.getBoolean(this, WidgetPreferences.KEY_SHOW_BORDER, WidgetPreferences.DEFAULT_SHOW_BORDER)
        val transparency = prefs.getInt(this, WidgetPreferences.KEY_TRANSPARENCY, WidgetPreferences.DEFAULT_TRANSPARENCY)
        seekTransparency.progress = transparency
        tvTransparencyValue.text = "$transparency%"
    }

    private fun setupListeners() {
        val updateListener = { updatePreview() }

        spinnerStyle.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = updatePreview()
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        spinnerTextSize.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = updatePreview()
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        switchGregorian.setOnCheckedChangeListener { _, _ -> updatePreview() }
        switchDayName.setOnCheckedChangeListener { _, _ -> updatePreview() }
        switchOccasion.setOnCheckedChangeListener { _, _ -> updatePreview() }
        switchBorder.setOnCheckedChangeListener { _, _ -> updatePreview() }

        seekTransparency.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                tvTransparencyValue.text = "$progress%"
                updatePreview()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        btnApply.setOnClickListener { saveAndApply() }
        btnReset.setOnClickListener { resetToDefaults() }
    }

    private fun updatePreview() {
        val style = spinnerStyle.selectedItemPosition
        val styleConfig = WidgetPreferences.getStyleConfig(style)
        val transparency = seekTransparency.progress

        // Background
        val bgColor = try { Color.parseColor(styleConfig.backgroundColorHex) } catch (e: Exception) { Color.parseColor("#CC1A6634") }
        val alpha = (transparency * 255 / 100)
        val finalBgColor = Color.argb(alpha, Color.red(bgColor), Color.green(bgColor), Color.blue(bgColor))
        previewContainer.setBackgroundColor(finalBgColor)

        // Text color
        val textColor = try { Color.parseColor(styleConfig.textColorHex) } catch (e: Exception) { Color.WHITE }
        val accentColor = try { Color.parseColor(styleConfig.accentColorHex) } catch (e: Exception) { Color.YELLOW }

        // Get current Hijri date
        val hijriDate = UmmAlQuraCalendar.getTodayHijri()
        val gregorianCal = Calendar.getInstance()

        // Day name
        if (switchDayName.isChecked) {
            tvPreviewDayName.text = UmmAlQuraCalendar.dayNamesArabic[hijriDate.dayOfWeek]
            tvPreviewDayName.setTextColor(textColor)
            tvPreviewDayName.visibility = View.VISIBLE
        } else {
            tvPreviewDayName.visibility = View.GONE
        }

        // Day number
        tvPreviewDay.text = UmmAlQuraCalendar.toArabicNumerals(hijriDate.day)
        tvPreviewDay.setTextColor(textColor)

        // Month
        tvPreviewMonth.text = UmmAlQuraCalendar.hijriMonthNamesArabic[hijriDate.month - 1]
        tvPreviewMonth.setTextColor(textColor)

        // Year
        tvPreviewYear.text = "${UmmAlQuraCalendar.toArabicNumerals(hijriDate.year)} هـ"
        tvPreviewYear.setTextColor(textColor)

        // Gregorian
        if (switchGregorian.isChecked) {
            val gDay = gregorianCal.get(Calendar.DAY_OF_MONTH)
            val gMonth = gregorianCal.get(Calendar.MONTH) + 1
            val gYear = gregorianCal.get(Calendar.YEAR)
            tvPreviewGregorian.text = "$gDay/$gMonth/$gYear م"
            tvPreviewGregorian.setTextColor(Color.argb(180, Color.red(textColor), Color.green(textColor), Color.blue(textColor)))
            tvPreviewGregorian.visibility = View.VISIBLE
        } else {
            tvPreviewGregorian.visibility = View.GONE
        }

        // Occasion
        if (switchOccasion.isChecked) {
            val occasion = UmmAlQuraCalendar.getIslamicOccasion(hijriDate)
            if (occasion != null) {
                tvPreviewOccasion.text = occasion
                tvPreviewOccasion.setTextColor(accentColor)
                tvPreviewOccasion.visibility = View.VISIBLE
            } else {
                tvPreviewOccasion.visibility = View.GONE
            }
        } else {
            tvPreviewOccasion.visibility = View.GONE
        }

        // Text sizes
        val textSizeLevel = spinnerTextSize.selectedItemPosition
        val (daySize, monthSize, yearSize, otherSize) = when (textSizeLevel) {
            WidgetPreferences.SIZE_SMALL -> arrayOf(36f, 13f, 12f, 10f)
            WidgetPreferences.SIZE_MEDIUM -> arrayOf(48f, 16f, 14f, 12f)
            WidgetPreferences.SIZE_LARGE -> arrayOf(60f, 20f, 17f, 14f)
            WidgetPreferences.SIZE_XLARGE -> arrayOf(72f, 24f, 20f, 16f)
            else -> arrayOf(48f, 16f, 14f, 12f)
        }
        tvPreviewDay.textSize = daySize
        tvPreviewMonth.textSize = monthSize
        tvPreviewYear.textSize = yearSize
        tvPreviewDayName.textSize = otherSize
        tvPreviewGregorian.textSize = otherSize
        tvPreviewOccasion.textSize = otherSize

        // Border
        val borderColor = try { Color.parseColor(styleConfig.borderColorHex) } catch (e: Exception) { Color.YELLOW }
        if (switchBorder.isChecked) {
            previewContainer.background = createBorderDrawable(finalBgColor, borderColor)
        } else {
            previewContainer.setBackgroundColor(finalBgColor)
        }
    }

    private fun createBorderDrawable(bgColor: Int, borderColor: Int): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(bgColor)
            setStroke(4, borderColor)
            cornerRadius = 16f
        }
    }

    private fun saveAndApply() {
        val prefs = WidgetPreferences
        prefs.setInt(this, WidgetPreferences.KEY_WIDGET_STYLE, spinnerStyle.selectedItemPosition)
        prefs.setInt(this, WidgetPreferences.KEY_TEXT_SIZE, spinnerTextSize.selectedItemPosition)
        prefs.setBoolean(this, WidgetPreferences.KEY_SHOW_GREGORIAN, switchGregorian.isChecked)
        prefs.setBoolean(this, WidgetPreferences.KEY_SHOW_DAY_NAME, switchDayName.isChecked)
        prefs.setBoolean(this, WidgetPreferences.KEY_SHOW_OCCASION, switchOccasion.isChecked)
        prefs.setBoolean(this, WidgetPreferences.KEY_SHOW_BORDER, switchBorder.isChecked)
        prefs.setInt(this, WidgetPreferences.KEY_TRANSPARENCY, seekTransparency.progress)

        val style = spinnerStyle.selectedItemPosition
        val styleConfig = WidgetPreferences.getStyleConfig(style)
        prefs.setString(this, WidgetPreferences.KEY_BACKGROUND_COLOR, styleConfig.backgroundColorHex)
        prefs.setString(this, WidgetPreferences.KEY_TEXT_COLOR, styleConfig.textColorHex)

        // Force widget update
        val mgr = AppWidgetManager.getInstance(this)
        val ids = mgr.getAppWidgetIds(ComponentName(this, UmmAlQuraWidget::class.java))
        val intent = Intent(this, UmmAlQuraWidget::class.java).apply {
            action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
        }
        sendBroadcast(intent)

        Toast.makeText(this, getString(R.string.settings_saved), Toast.LENGTH_SHORT).show()
    }

    private fun resetToDefaults() {
        val prefs = WidgetPreferences
        prefs.setInt(this, WidgetPreferences.KEY_WIDGET_STYLE, WidgetPreferences.DEFAULT_WIDGET_STYLE)
        prefs.setInt(this, WidgetPreferences.KEY_TEXT_SIZE, WidgetPreferences.DEFAULT_TEXT_SIZE)
        prefs.setBoolean(this, WidgetPreferences.KEY_SHOW_GREGORIAN, WidgetPreferences.DEFAULT_SHOW_GREGORIAN)
        prefs.setBoolean(this, WidgetPreferences.KEY_SHOW_DAY_NAME, WidgetPreferences.DEFAULT_SHOW_DAY_NAME)
        prefs.setBoolean(this, WidgetPreferences.KEY_SHOW_OCCASION, WidgetPreferences.DEFAULT_SHOW_OCCASION)
        prefs.setBoolean(this, WidgetPreferences.KEY_SHOW_BORDER, WidgetPreferences.DEFAULT_SHOW_BORDER)
        prefs.setInt(this, WidgetPreferences.KEY_TRANSPARENCY, WidgetPreferences.DEFAULT_TRANSPARENCY)
        loadCurrentSettings()
        updatePreview()
        Toast.makeText(this, getString(R.string.settings_reset), Toast.LENGTH_SHORT).show()
    }
}
