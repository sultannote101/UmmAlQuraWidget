package com.islamicwidget.ummalqura

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.View
import android.widget.RemoteViews
import java.util.Calendar

class UmmAlQuraWidget : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId)
        }
        scheduleNextUpdate(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_BOOT_COMPLETED,
            "com.islamicwidget.ummalqura.UPDATE_WIDGET" -> {
                val mgr = AppWidgetManager.getInstance(context)
                val ids = mgr.getAppWidgetIds(ComponentName(context, UmmAlQuraWidget::class.java))
                onUpdate(context, mgr, ids)
            }
        }
    }

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        scheduleNextUpdate(context)
    }

    override fun onDisabled(context: Context) {
        super.onDisabled(context)
        cancelScheduledUpdate(context)
    }

    companion object {
        fun updateWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            val prefs = WidgetPreferences
            val views = RemoteViews(context.packageName, R.layout.widget_layout)

            // Get Hijri date
            val hijriDate = UmmAlQuraCalendar.getTodayHijri()
            val gregorianCal = Calendar.getInstance()

            // Apply style settings
            val style = prefs.getInt(context, WidgetPreferences.KEY_WIDGET_STYLE, WidgetPreferences.DEFAULT_WIDGET_STYLE)
            val styleConfig = prefs.getStyleConfig(style)

            val bgColorStr = prefs.getString(context, WidgetPreferences.KEY_BACKGROUND_COLOR, styleConfig.backgroundColorHex)
            val textColorStr = prefs.getString(context, WidgetPreferences.KEY_TEXT_COLOR, styleConfig.textColorHex)
            val transparency = prefs.getInt(context, WidgetPreferences.KEY_TRANSPARENCY, WidgetPreferences.DEFAULT_TRANSPARENCY)
            val showBorder = prefs.getBoolean(context, WidgetPreferences.KEY_SHOW_BORDER, WidgetPreferences.DEFAULT_SHOW_BORDER)
            val showGregorian = prefs.getBoolean(context, WidgetPreferences.KEY_SHOW_GREGORIAN, WidgetPreferences.DEFAULT_SHOW_GREGORIAN)
            val showDayName = prefs.getBoolean(context, WidgetPreferences.KEY_SHOW_DAY_NAME, WidgetPreferences.DEFAULT_SHOW_DAY_NAME)
            val showOccasion = prefs.getBoolean(context, WidgetPreferences.KEY_SHOW_OCCASION, WidgetPreferences.DEFAULT_SHOW_OCCASION)
            val textSizeLevel = prefs.getInt(context, WidgetPreferences.KEY_TEXT_SIZE, WidgetPreferences.DEFAULT_TEXT_SIZE)

            // Set background color with transparency
            try {
                val bgColor = Color.parseColor(bgColorStr)
                val alpha = (transparency * 255 / 100)
                val finalBgColor = Color.argb(alpha, Color.red(bgColor), Color.green(bgColor), Color.blue(bgColor))
                views.setInt(R.id.widget_container, "setBackgroundColor", finalBgColor)
            } catch (e: Exception) {
                views.setInt(R.id.widget_container, "setBackgroundColor", Color.parseColor("#CC1A6634"))
            }

            // Set text color
            val textColor = try { Color.parseColor(textColorStr) } catch (e: Exception) { Color.WHITE }

            // Day name
            if (showDayName) {
                val dayName = UmmAlQuraCalendar.dayNamesArabic[hijriDate.dayOfWeek]
                views.setTextViewText(R.id.tv_day_name, dayName)
                views.setTextColor(R.id.tv_day_name, textColor)
                views.setViewVisibility(R.id.tv_day_name, View.VISIBLE)
            } else {
                views.setViewVisibility(R.id.tv_day_name, View.GONE)
            }

            // Hijri day number (large)
            val dayNum = UmmAlQuraCalendar.toArabicNumerals(hijriDate.day)
            views.setTextViewText(R.id.tv_hijri_day, dayNum)
            views.setTextColor(R.id.tv_hijri_day, textColor)

            // Hijri month name
            val monthName = UmmAlQuraCalendar.hijriMonthNamesArabic[hijriDate.month - 1]
            views.setTextViewText(R.id.tv_hijri_month, monthName)
            views.setTextColor(R.id.tv_hijri_month, textColor)

            // Hijri year
            val yearStr = "${UmmAlQuraCalendar.toArabicNumerals(hijriDate.year)} هـ"
            views.setTextViewText(R.id.tv_hijri_year, yearStr)
            views.setTextColor(R.id.tv_hijri_year, textColor)

            // Gregorian date
            if (showGregorian) {
                val gDay = gregorianCal.get(Calendar.DAY_OF_MONTH)
                val gMonth = gregorianCal.get(Calendar.MONTH) + 1
                val gYear = gregorianCal.get(Calendar.YEAR)
                val gregorianStr = "$gDay/$gMonth/$gYear م"
                views.setTextViewText(R.id.tv_gregorian, gregorianStr)
                views.setTextColor(R.id.tv_gregorian, Color.argb(200, Color.red(textColor), Color.green(textColor), Color.blue(textColor)))
                views.setViewVisibility(R.id.tv_gregorian, View.VISIBLE)
            } else {
                views.setViewVisibility(R.id.tv_gregorian, View.GONE)
            }

            // Islamic occasion
            if (showOccasion) {
                val occasion = UmmAlQuraCalendar.getIslamicOccasion(hijriDate)
                if (occasion != null) {
                    views.setTextViewText(R.id.tv_occasion, occasion)
                    views.setTextColor(R.id.tv_occasion, Color.parseColor(styleConfig.accentColorHex))
                    views.setViewVisibility(R.id.tv_occasion, View.VISIBLE)
                } else {
                    views.setViewVisibility(R.id.tv_occasion, View.GONE)
                }
            } else {
                views.setViewVisibility(R.id.tv_occasion, View.GONE)
            }

            // Apply text size
            val (daySize, monthSize, yearSize, otherSize) = when (textSizeLevel) {
                WidgetPreferences.SIZE_SMALL -> arrayOf(36f, 13f, 12f, 10f)
                WidgetPreferences.SIZE_MEDIUM -> arrayOf(48f, 16f, 14f, 12f)
                WidgetPreferences.SIZE_LARGE -> arrayOf(60f, 20f, 17f, 14f)
                WidgetPreferences.SIZE_XLARGE -> arrayOf(72f, 24f, 20f, 16f)
                else -> arrayOf(48f, 16f, 14f, 12f)
            }

            views.setFloat(R.id.tv_hijri_day, "setTextSize", daySize)
            views.setFloat(R.id.tv_hijri_month, "setTextSize", monthSize)
            views.setFloat(R.id.tv_hijri_year, "setTextSize", yearSize)
            views.setFloat(R.id.tv_day_name, "setTextSize", otherSize)
            views.setFloat(R.id.tv_gregorian, "setTextSize", otherSize)
            views.setFloat(R.id.tv_occasion, "setTextSize", otherSize)

            // Click to open config
            val configIntent = Intent(context, MainActivity::class.java)
            val pendingIntent = PendingIntent.getActivity(
                context, 0, configIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_container, pendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }

        private fun scheduleNextUpdate(context: Context) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent("com.islamicwidget.ummalqura.UPDATE_WIDGET")
            val pendingIntent = PendingIntent.getBroadcast(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Schedule for midnight
            val midnight = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_MONTH, 1)
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }

            alarmManager.set(AlarmManager.RTC, midnight.timeInMillis, pendingIntent)
        }

        private fun cancelScheduledUpdate(context: Context) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent("com.islamicwidget.ummalqura.UPDATE_WIDGET")
            val pendingIntent = PendingIntent.getBroadcast(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            alarmManager.cancel(pendingIntent)
        }
    }
}
