package com.islamicwidget.ummalqura

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import java.util.Calendar

class UmmAlQuraWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            updateWidget(context, appWidgetManager, id)
        }
        scheduleNextUpdate(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_BOOT_COMPLETED,
            "com.islamicwidget.ummalqura.UPDATE_WIDGET" -> {
                val mgr = AppWidgetManager.getInstance(context)
                val ids = mgr.getAppWidgetIds(ComponentName(context, UmmAlQuraWidget::class.java))
                if (ids.isNotEmpty()) onUpdate(context, mgr, ids)
            }
        }
    }

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        scheduleNextUpdate(context)
    }

    override fun onDisabled(context: Context) {
        super.onDisabled(context)
        cancelScheduledUpdate(context)
    }

    companion object {

        fun updateWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
            try {
                val prefs = WidgetPreferences
                val views = RemoteViews(context.packageName, R.layout.widget_layout)

                val hijriDate = UmmAlQuraCalendar.getTodayHijri()
                val gregorianCal = Calendar.getInstance()

                val style = prefs.getInt(context, WidgetPreferences.KEY_WIDGET_STYLE, WidgetPreferences.DEFAULT_WIDGET_STYLE)
                val styleConfig = prefs.getStyleConfig(style)
                val transparency = prefs.getInt(context, WidgetPreferences.KEY_TRANSPARENCY, WidgetPreferences.DEFAULT_TRANSPARENCY)
                val showBorder = prefs.getBoolean(context, WidgetPreferences.KEY_SHOW_BORDER, WidgetPreferences.DEFAULT_SHOW_BORDER)
                val showGregorian = prefs.getBoolean(context, WidgetPreferences.KEY_SHOW_GREGORIAN, WidgetPreferences.DEFAULT_SHOW_GREGORIAN)
                val showDayName = prefs.getBoolean(context, WidgetPreferences.KEY_SHOW_DAY_NAME, WidgetPreferences.DEFAULT_SHOW_DAY_NAME)
                val showOccasion = prefs.getBoolean(context, WidgetPreferences.KEY_SHOW_OCCASION, WidgetPreferences.DEFAULT_SHOW_OCCASION)
                val textSizeLevel = prefs.getInt(context, WidgetPreferences.KEY_TEXT_SIZE, WidgetPreferences.DEFAULT_TEXT_SIZE)

                // Background color with transparency
                val bgColorStr = prefs.getString(context, WidgetPreferences.KEY_BACKGROUND_COLOR, styleConfig.backgroundColorHex)
                val bgColor = try { Color.parseColor(bgColorStr) } catch (e: Exception) { Color.parseColor("#CC1A6634") }
                val alpha = (transparency * 255 / 100)
                val finalBgColor = Color.argb(alpha, Color.red(bgColor), Color.green(bgColor), Color.blue(bgColor))

                val textColorStr = prefs.getString(context, WidgetPreferences.KEY_TEXT_COLOR, styleConfig.textColorHex)
                val textColor = try { Color.parseColor(textColorStr) } catch (e: Exception) { Color.WHITE }
                val accentColor = try { Color.parseColor(styleConfig.accentColorHex) } catch (e: Exception) { Color.parseColor("#FFD4AF37") }
                val borderColor = try { Color.parseColor(styleConfig.borderColorHex) } catch (e: Exception) { Color.parseColor("#FFD4AF37") }

                // Apply background
                views.setInt(R.id.widget_container, "setBackgroundColor", finalBgColor)

                // Day name
                if (showDayName) {
                    views.setTextViewText(R.id.tv_day_name, UmmAlQuraCalendar.dayNamesArabic[hijriDate.dayOfWeek])
                    views.setTextColor(R.id.tv_day_name, Color.argb(200, Color.red(textColor), Color.green(textColor), Color.blue(textColor)))
                    views.setViewVisibility(R.id.tv_day_name, View.VISIBLE)
                } else {
                    views.setViewVisibility(R.id.tv_day_name, View.GONE)
                }

                // Hijri day
                views.setTextViewText(R.id.tv_hijri_day, UmmAlQuraCalendar.toArabicNumerals(hijriDate.day))
                views.setTextColor(R.id.tv_hijri_day, textColor)

                // Hijri month - in gold/accent color
                views.setTextViewText(R.id.tv_hijri_month, UmmAlQuraCalendar.hijriMonthNamesArabic[hijriDate.month - 1])
                views.setTextColor(R.id.tv_hijri_month, accentColor)

                // Hijri year
                views.setTextViewText(R.id.tv_hijri_year, "${UmmAlQuraCalendar.toArabicNumerals(hijriDate.year)} هـ")
                views.setTextColor(R.id.tv_hijri_year, Color.argb(220, Color.red(textColor), Color.green(textColor), Color.blue(textColor)))

                // Gregorian date
                if (showGregorian) {
                    val gDay = gregorianCal.get(Calendar.DAY_OF_MONTH)
                    val gMonth = gregorianCal.get(Calendar.MONTH) + 1
                    val gYear = gregorianCal.get(Calendar.YEAR)
                    views.setTextViewText(R.id.tv_gregorian, "$gDay/$gMonth/$gYear م")
                    views.setTextColor(R.id.tv_gregorian, Color.argb(180, Color.red(textColor), Color.green(textColor), Color.blue(textColor)))
                    views.setViewVisibility(R.id.tv_gregorian, View.VISIBLE)
                } else {
                    views.setViewVisibility(R.id.tv_gregorian, View.GONE)
                }

                // Islamic occasion
                if (showOccasion) {
                    val occasion = UmmAlQuraCalendar.getIslamicOccasion(hijriDate)
                    if (occasion != null) {
                        views.setTextViewText(R.id.tv_occasion, occasion)
                        views.setTextColor(R.id.tv_occasion, Color.parseColor("#FFFFD700"))
                        views.setViewVisibility(R.id.tv_occasion, View.VISIBLE)
                    } else {
                        views.setViewVisibility(R.id.tv_occasion, View.GONE)
                    }
                } else {
                    views.setViewVisibility(R.id.tv_occasion, View.GONE)
                }

                // Text sizes
                val (daySize, monthSize, yearSize, otherSize) = when (textSizeLevel) {
                    WidgetPreferences.SIZE_SMALL  -> arrayOf(38f, 13f, 11f, 10f)
                    WidgetPreferences.SIZE_MEDIUM -> arrayOf(50f, 16f, 13f, 11f)
                    WidgetPreferences.SIZE_LARGE  -> arrayOf(62f, 19f, 15f, 13f)
                    WidgetPreferences.SIZE_XLARGE -> arrayOf(74f, 22f, 18f, 15f)
                    else -> arrayOf(50f, 16f, 13f, 11f)
                }
                views.setTextViewTextSize(R.id.tv_hijri_day, TypedValue.COMPLEX_UNIT_SP, daySize)
                views.setTextViewTextSize(R.id.tv_hijri_month, TypedValue.COMPLEX_UNIT_SP, monthSize)
                views.setTextViewTextSize(R.id.tv_hijri_year, TypedValue.COMPLEX_UNIT_SP, yearSize)
                views.setTextViewTextSize(R.id.tv_day_name, TypedValue.COMPLEX_UNIT_SP, otherSize)
                views.setTextViewTextSize(R.id.tv_gregorian, TypedValue.COMPLEX_UNIT_SP, otherSize)
                views.setTextViewTextSize(R.id.tv_occasion, TypedValue.COMPLEX_UNIT_SP, otherSize)

                // Click to open settings
                val configIntent = Intent(context, MainActivity::class.java)
                val pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                val pendingIntent = PendingIntent.getActivity(context, appWidgetId, configIntent, pendingFlags)
                views.setOnClickPendingIntent(R.id.widget_container, pendingIntent)

                appWidgetManager.updateAppWidget(appWidgetId, views)

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        private fun scheduleNextUpdate(context: Context) {
            try {
                val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val intent = Intent("com.islamicwidget.ummalqura.UPDATE_WIDGET").apply {
                    setPackage(context.packageName)
                }
                val pendingIntent = PendingIntent.getBroadcast(
                    context, 100, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                val midnight = Calendar.getInstance().apply {
                    add(Calendar.DAY_OF_MONTH, 1)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 1)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (alarmManager.canScheduleExactAlarms()) {
                        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC, midnight.timeInMillis, pendingIntent)
                    } else {
                        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC, midnight.timeInMillis, pendingIntent)
                    }
                } else {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC, midnight.timeInMillis, pendingIntent)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        private fun cancelScheduledUpdate(context: Context) {
            try {
                val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val intent = Intent("com.islamicwidget.ummalqura.UPDATE_WIDGET").apply {
                    setPackage(context.packageName)
                }
                val pendingIntent = PendingIntent.getBroadcast(
                    context, 100, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                alarmManager.cancel(pendingIntent)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
