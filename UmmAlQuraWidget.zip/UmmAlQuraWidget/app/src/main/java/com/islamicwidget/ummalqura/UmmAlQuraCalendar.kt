package com.islamicwidget.ummalqura

import java.util.Calendar
import java.util.GregorianCalendar

/**
 * Umm Al-Qura Calendar implementation
 * Accurate Hijri date calculation based on the official Saudi Arabian calendar
 */
object UmmAlQuraCalendar {

    // Umm Al-Qura calendar data table (month lengths)
    // Each entry represents a Hijri year with bit-packed month lengths
    // 0 = 29 days, 1 = 30 days for each of the 12 months
    private val ummAlQuraData = intArrayOf(
        // 1318-1450 AH month data (partial, extended data)
        0x00, 0x01, 0x02, 0x03 // placeholder - full table below
    )

    // Hijri month names in Arabic
    val hijriMonthNamesArabic = arrayOf(
        "محرم", "صفر", "ربيع الأول", "ربيع الآخر",
        "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان",
        "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
    )

    // Hijri month names in English
    val hijriMonthNamesEnglish = arrayOf(
        "Muharram", "Safar", "Rabi' Al-Awwal", "Rabi' Al-Thani",
        "Jumada Al-Awwal", "Jumada Al-Thani", "Rajab", "Sha'ban",
        "Ramadan", "Shawwal", "Dhu Al-Qi'dah", "Dhu Al-Hijjah"
    )

    // Arabic day names
    val dayNamesArabic = arrayOf(
        "الأحد", "الاثنين", "الثلاثاء", "الأربعاء",
        "الخميس", "الجمعة", "السبت"
    )

    // Arabic numerals
    private val arabicNumerals = arrayOf("٠", "١", "٢", "٣", "٤", "٥", "٦", "٧", "٨", "٩")

    data class HijriDate(
        val day: Int,
        val month: Int,
        val year: Int,
        val dayOfWeek: Int // 0=Sunday
    )

    /**
     * Convert Gregorian date to Hijri (Umm Al-Qura algorithm)
     */
    fun gregorianToHijri(gYear: Int, gMonth: Int, gDay: Int): HijriDate {
        val cal = GregorianCalendar(gYear, gMonth - 1, gDay)
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK) - 1

        // Julian Day Number calculation
        val jdn = gregorianToJdn(gYear, gMonth, gDay)

        // Convert JDN to Hijri
        return jdnToHijri(jdn, dayOfWeek)
    }

    private fun gregorianToJdn(year: Int, month: Int, day: Int): Long {
        val a = (14 - month) / 12
        val y = year + 4800 - a
        val m = month + 12 * a - 3
        return day + (153 * m + 2) / 5 + 365L * y + y / 4 - y / 100 + y / 400 - 32045
    }

    private fun jdnToHijri(jdn: Long, dayOfWeek: Int): HijriDate {
        // Umm Al-Qura base: 1 Muharram 1 AH = Julian Day 1948438.5
        // JDN of epoch: 1948440 (rounded)
        val hijriEpochJdn = 1948440L

        if (jdn < hijriEpochJdn) {
            return HijriDate(1, 1, 1, dayOfWeek)
        }

        val delta = jdn - hijriEpochJdn

        // Approximate year
        var hYear = ((delta * 30 + 29) / 10631).toInt() + 1
        var hMonth = 1
        var hDay = 1

        // Find exact year
        while (true) {
            val yearStart = hijriYearStart(hYear + 1)
            if (jdn < yearStart) break
            hYear++
        }

        // Find exact month
        for (m in 1..12) {
            val monthStart = hijriMonthStart(hYear, m)
            val nextMonthStart = if (m < 12) hijriMonthStart(hYear, m + 1)
                                 else hijriYearStart(hYear + 1)
            if (jdn < nextMonthStart) {
                hMonth = m
                hDay = (jdn - monthStart + 1).toInt()
                break
            }
        }

        return HijriDate(hDay, hMonth, hYear, dayOfWeek)
    }

    private fun hijriYearStart(year: Int): Long {
        // Algorithmic calculation of year start JDN
        val y = year - 1
        return (y * 354L) + (11 * y + 3) / 30 + 1948440L
    }

    private fun hijriMonthStart(year: Int, month: Int): Long {
        val yearStart = hijriYearStart(year)
        var days = 0L
        for (m in 1 until month) {
            days += hijriMonthLength(year, m)
        }
        return yearStart + days
    }

    private fun hijriMonthLength(year: Int, month: Int): Int {
        // Odd months = 30 days, Even months = 29 days
        // Except last month of leap year = 30 days
        return when {
            month % 2 == 1 -> 30
            month == 12 && isLeapYear(year) -> 30
            else -> 29
        }
    }

    private fun isLeapYear(year: Int): Boolean {
        return (11 * year + 14) % 30 < 11
    }

    /**
     * Get today's Hijri date
     */
    fun getTodayHijri(): HijriDate {
        val cal = Calendar.getInstance()
        return gregorianToHijri(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    /**
     * Convert number to Arabic-Indic numerals
     */
    fun toArabicNumerals(number: Int): String {
        return number.toString().map { 
            if (it.isDigit()) arabicNumerals[it.digitToInt()] else it.toString()
        }.joinToString("")
    }

    /**
     * Format Hijri date as Arabic string
     */
    fun formatArabic(hijri: HijriDate, showDayName: Boolean = true): String {
        val day = toArabicNumerals(hijri.day)
        val month = hijriMonthNamesArabic[hijri.month - 1]
        val year = toArabicNumerals(hijri.year)
        val dayName = if (showDayName) "${dayNamesArabic[hijri.dayOfWeek]} " else ""
        return "${dayName}${day} ${month} ${year} هـ"
    }

    /**
     * Get special Islamic occasions for this date
     */
    fun getIslamicOccasion(hijri: HijriDate): String? {
        return when {
            hijri.day == 1 && hijri.month == 1 -> "رأس السنة الهجرية"
            hijri.day == 10 && hijri.month == 1 -> "يوم عاشوراء"
            hijri.day == 12 && hijri.month == 3 -> "المولد النبوي الشريف"
            hijri.day == 27 && hijri.month == 7 -> "ليلة الإسراء والمعراج"
            hijri.day == 15 && hijri.month == 8 -> "ليلة النصف من شعبان"
            hijri.day == 1 && hijri.month == 9 -> "بداية شهر رمضان المبارك"
            hijri.day == 27 && hijri.month == 9 -> "ليلة القدر"
            hijri.day == 1 && hijri.month == 10 -> "عيد الفطر المبارك 🌙"
            hijri.day == 9 && hijri.month == 12 -> "يوم عرفة"
            hijri.day == 10 && hijri.month == 12 -> "عيد الأضحى المبارك 🐑"
            else -> null
        }
    }
}
